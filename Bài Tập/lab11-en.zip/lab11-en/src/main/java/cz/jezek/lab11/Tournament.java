package cz.jezek.lab11;

import java.util.Collections;
import java.util.List;

public class Tournament {

  private List<Player> players;
  private List<Match> matches;

  public static Tournament generate() {
    List<Player> players = Collections.emptyList();

    // TODO Generate a list of 10 random players using the stream and then filter so that it does not contain players with the same name

    List<Match> matches = Collections.emptyList();

    // TODO Use the stream to generate a list of 50 matches between random players (from the list of players) with a random result. Make sure the player does not play with himself.

    return new Tournament(players, matches);
  }

  public Tournament(List<Player> players, List<Match> matches) {
    this.players = players;
    this.matches = matches;
  }

  public List<Player> getPlayers() {
    return players;
  }

  public List<Match> getMatches() {
    return matches;
  }

  public Player getRandomPlayer() {
    return RandomGenarator.selectRandom(players);
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("Player count ").append(players.size())
        .append(" Match count: ").append(matches.size());
    builder.append("\n");

    // TODO Use the stream to add a listing of all players to the builder. Individual players are separated by a "\ n" character
    builder.append(/* vypis vsech hracu */"");
    builder.append("\n\nMatches:\n");

    // TODO Use the stream to add a listing of all entries to the builder. Individual matches are separated by a "\ n" character
    builder.append(/* list of all matches */"");

    return builder.toString();
  }

}
