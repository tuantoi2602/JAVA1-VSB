package cz.jezek.lab11;

public class StreamMain {

  public static void main(String[] args) {
    Tournament tournament = Tournament.generate();

    printStatAboutTournament(tournament);

    saveTournament(tournament);
    loadTournament();
  }

  public static void printStatAboutTournament(Tournament tournament) {
    System.out.println(tournament);
    Player player = tournament.getRandomPlayer();

    System.out.println(player);
    System.out.print("Počet zápasů: ");
    //TODO Show the number of matches played by a given player (using Streams)
    System.out.print("Vstřeleno gólů: ");
    //TODO Show the number of goals scored by a given player (help Streams)

    Oponents oponents = new Oponents(tournament.getRandomPlayer(),
        tournament.getRandomPlayer());
    System.out.println("Statistika vzájemných zápasů:" + oponents);
    System.out.print("Zápasy: ");
    //TODO List the matches played between the given players (using the stream)
    System.out.print("Počet zápasů: ");
    //TODO Print the number of matches played between the given players (using the stream)
    System.out.print("Zápas s největším počtem branek:");
    //TODO Show match with the largest total number (sum of both players) scored goals between relevant players (help Streams)
  }

  public static void loadTournament() {
    //TODO Load a serialized tournament from a file
  }

  public static void saveTournament(Tournament tournament) {
    //TODO Save the tournament to a file using object serialization.
  }
}
