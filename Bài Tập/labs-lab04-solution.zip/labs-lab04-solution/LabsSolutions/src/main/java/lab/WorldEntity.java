package lab;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;

public abstract class WorldEntity implements DrawableSimulable{
	
	private Point2D position;
	
	private final World world;
	
	public WorldEntity(Point2D position, World world) {
		super();
		this.position = position;
		this.world = world;
	}
	
	protected Point2D getPosition() {
		return position;
	}

	protected void setPosition(Point2D position) {
		this.position = position;
	}

	protected World getWorld() {
		return world;
	}
	
	@Override
	public final void draw(GraphicsContext gc) {
		gc.save();
		drawInternal(gc);
		gc.restore();
	}

	protected abstract void drawInternal(GraphicsContext gc);
	
}
