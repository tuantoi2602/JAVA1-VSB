package lab;

import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class BulletAnimated extends WorldEntity implements DrawableSimulable, Collisionable{

	
	private Point2D start;
	private Point2D speed;
	private Point2D initialSpeed;
	private double size;
	private double mass = 2;
	private double strenghtOfCannon = 2;
	private double cannonLength = 100;
	private boolean accelerate = true;
	private boolean hitToGround = false;

	private double crossSectionalArea;
	private double dragCoefficient = 0.47;
	
	private Image image;
	private Cannon cannon;

	public BulletAnimated(World world, Cannon cannon) {
		this(world, cannon, new Point2D(0, 0), new Point2D(0, 0), 10);
	}

	public BulletAnimated(World world, Cannon cannon, Point2D start, Point2D speed, double size) {
		super(start, world);
		this.start = start;
		this.initialSpeed = speed;
		this.speed = speed;
		this.size = size;
		this.cannon = cannon;
		image = new Image(getClass().getResourceAsStream("fireball-transparent.gif"), size, size,
				true, true);
	}

	@Override
	public void simulate(double timeStep) {
		if (accelerate && start.distance(getPosition()) < cannonLength) {
			double cannonAngle = cannon.getAngle(); 
			speed = speed
					.add(new Point2D(Math.cos(cannonAngle) * strenghtOfCannon, Math.sin(cannonAngle) * strenghtOfCannon)
							.multiply(1 / mass));
		} else if (!hitToGround) {
			accelerate = false;
			Point2D airResistanceforce = new Point2D(
					-1. / 2 * crossSectionalArea * Constants.AIR_DENSITY * dragCoefficient * Math.pow(speed.getX(), 2),
					-1. / 2 * crossSectionalArea * Constants.AIR_DENSITY * 0.47 * Math.pow(speed.getY(), 2));
			Point2D acceleration = new Point2D(-airResistanceforce.getX() * mass,
					(-Constants.GRAVITATIONAL_ACCELERATION + airResistanceforce.getY()) * mass);
			speed = speed.add(acceleration.multiply(timeStep / 1000));
		}
		if (!hitToGround) {
			setPosition(getPosition().add(speed));
			if (!accelerate && getPosition().getY() <= size / 2) {
				hitToGround = true;
				setPosition(new Point2D(getPosition().getX(), size / 2));
			}
		} else {
			reload();
		}
		
		
	}

	@Override
	public Rectangle2D getBoundingBox() {
		return new Rectangle2D(getPosition().getX(), getPosition().getY(), size, size);
	}
	
	@Override
	protected void drawInternal(GraphicsContext gc) {
		Point2D canvasPosition = getWorld().getCanvasPoint(getPosition());
		gc.drawImage(image, canvasPosition.getX(), canvasPosition.getY());
	}

	public void reload() {
		setPosition(start);
		speed = initialSpeed;
		hitToGround = false;
		accelerate = true;
	}
	
}
