package lab;

import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;

public class Dragon extends WorldEntity implements DrawableSimulable, Hittingable{
	
	private Point2D speed;
	
	private final double size = 45;

	public Dragon(World world, Point2D position, Point2D speed) {
		super(position, world);
		this.speed = speed;
	}

	@Override
	public void simulate(double timeDelta) {
		double timeDeltaS = timeDelta/1000.0;
		double newX = (getPosition().getX() + speed.getX() * timeDeltaS + getWorld().getWidth()) % getWorld().getWidth(); 
		double newY = (getPosition().getY() + speed.getY() * timeDeltaS + getWorld().getHeight()) % getWorld().getHeight();
		setPosition(new Point2D(newX, newY));
	}

	@Override
	public Rectangle2D getBoundingBox() {
		return new Rectangle2D(getPosition().getX(), getPosition().getY(), size, size);
	}

	@Override
	public void hitBy(Collisionable another) {
		//another is type of BulletAnimated
		speed = speed.multiply(-1.);
	}

	@Override
	protected void drawInternal(GraphicsContext gc) {
		Point2D canvasPosition = getWorld().getCanvasPoint(getPosition());
		gc.drawImage(Constants.DRAGON_IMAGE, canvasPosition.getX(), canvasPosition.getY(), size, size);
	}
}
