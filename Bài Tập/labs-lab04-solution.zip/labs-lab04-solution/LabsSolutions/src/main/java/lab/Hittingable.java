package lab;

public interface Hittingable extends Collisionable {
	void hitBy(Collisionable other);
}
