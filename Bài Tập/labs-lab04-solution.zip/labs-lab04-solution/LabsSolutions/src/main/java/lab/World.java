package lab;

import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

public class World {
	
	private double width;
	
	private double height;
	
	private DrawableSimulable []entities;

	public World(double width, double height) {
		super();
		this.width = width;
		this.height = height;
		Cannon canon = new Cannon(this, new Point2D(50, 50), new Point2D(100, 20));
		entities = new DrawableSimulable[] { canon,
				new BulletAnimated(this, canon, new Point2D(30, 60), new Point2D(0, 0), 40),
				new Dragon(this, new Point2D(50, 200), new Point2D(100, 5)),
				new Dragon(this, new Point2D(50, 230), new Point2D(60, 5)),
				new Dragon(this, new Point2D(50, 270), new Point2D(-50, 20)) };

	}

	public Point2D getCanvasPoint(Point2D worldPoint) {
		return new Point2D(worldPoint.getX(), height - worldPoint.getY());
	}

	public void draw(Canvas canvas) {
		GraphicsContext gc = canvas.getGraphicsContext2D();
		gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
		
		//foreach entity in entities call method draw
		for(DrawableSimulable entity: entities) {
			entity.draw(gc);
		}
	}

	public void simulate(int timeDelta) {
		
		//foreach entity in entities call method draw
		for(DrawableSimulable entity: entities) {
			entity.simulate(timeDelta);
			//if entity is type of CollisionChecking then:
			if (entity instanceof Collisionable && !(entity instanceof Hittingable)) {
				Collisionable typedEntity = (Collisionable) entity;
				//for another entity that is type of CollisionChecking
				for(DrawableSimulable anotherEntity: entities) {
					if (anotherEntity != entity && anotherEntity instanceof Hittingable) {
						Hittingable typedAnotherEntity = (Hittingable) anotherEntity;
						//if entity intersects with another entity then:
						if (typedEntity.intersects(typedAnotherEntity)) {
							//another entity is hi by entity
							typedAnotherEntity.hitBy(typedEntity);
						}
					}

				}
			}
			
		}
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

}
