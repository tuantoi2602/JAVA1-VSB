package table_view;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
 
public class TableViewSample extends Application {
 
	private final PersonDAO dao;
	
	private TableView<Person> table = new TableView<>();
    
    private final ObservableList<Person> data;
    
    final HBox hb = new HBox();
	private TextField addFirstName;
	private TextField addLastName;
	private TextField addEmail;
 
    public static void main(String[] args) {
        launch(args);
    }
 
    public TableViewSample() {
    	dao = new PersonDAO(new PostgresqlJDBCDialect());
    	data = FXCollections.observableArrayList(dao.getAll());	
	}
    
    @SuppressWarnings("unchecked")
	@Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Table View Sample");
        stage.setWidth(450);
        stage.setHeight(550);
 
        final Label label = new Label("Address Book");
        label.setFont(new Font("Arial", 20));
 
        table.setEditable(true);
        table.setItems(data);
        
        TableColumn<Person, String> firstNameCol = constructColumn("First Name","firstName", this::handleOnEditCommitFirstName);
        TableColumn<Person,String> lastNameCol = constructColumn("Last Name","lastName", this::handleOnEditCommitLastName);
        TableColumn<Person,String> emailCol = constructColumn("Email","email",this::handleOnEditCommitEmail);
        table.getColumns().addAll(firstNameCol, lastNameCol, emailCol);
 
        
        addFirstName = constructTextField(firstNameCol,"First Name");
        addLastName = constructTextField(lastNameCol,"Last Name");
        addEmail = constructTextField(emailCol,"Email");
        final Button addButton = new Button("Add");
        addButton.setOnAction(this::handleOnAdd);
 
        hb.getChildren().addAll(addFirstName, addLastName, addEmail, addButton);
        hb.setSpacing(3);
 
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table, hb);
        
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
        stage.setScene(scene);
        
        stage.show();
        stage.setOnCloseRequest(this::exitProgram);
    }

	private TextField constructTextField(TableColumn<Person, String> column, String string) {
		TextField result = new TextField();
		result.setPromptText("First Name");
        result.setMaxWidth(column.getPrefWidth());
        return result;
	}

	private TableColumn<Person, String> constructColumn(String name, String propertyName,
			EventHandler<CellEditEvent<Person, String>> callback) {
		TableColumn<Person, String> col = new TableColumn<>(name);
		col.setMinWidth(100);
		col.setCellValueFactory(new PropertyValueFactory<>(propertyName));
		col.setCellFactory(TextFieldTableCell.forTableColumn());
		col.setOnEditCommit(callback);
		return col;
	}

	private void handleOnAdd(ActionEvent e) {
		Person p = new Person(addFirstName.getText(), addLastName.getText(), addEmail.getText());
		p = dao.insertPerson(p);
		data.add(p);
		addFirstName.clear();
		addLastName.clear();
		addEmail.clear();
	}
    
	private void handleOnEditCommitFirstName(CellEditEvent<Person, String> t) {
		Person p = t.getTableView().getItems().get(t.getTablePosition().getRow());
		p.setFirstName(t.getNewValue());
		dao.updatePerson(p);
	}
	
	private void handleOnEditCommitLastName(CellEditEvent<Person, String> t) {
		Person p = t.getTableView().getItems().get(t.getTablePosition().getRow());
		p.setLastName(t.getNewValue());
		dao.updatePerson(p);
	}
	
	private void handleOnEditCommitEmail(CellEditEvent<Person, String> t) {
		Person p = t.getTableView().getItems().get(t.getTablePosition().getRow());
		p.setEmail(t.getNewValue());
		dao.updatePerson(p);
	}
	private void exitProgram(WindowEvent evt) {
		try {
			dao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}